function Story(){
    this.header = 'This is a header';
    this.paragraph = 'This is a text';

   
    //  randomDate(new Date(2012, 0, 1), new Date());
    this.date = new Date();
   
}