function main() {
    var socialNetwork = new SocialNetwork("FaceNoteBook");
    console.log(socialNetwork);
}

main();