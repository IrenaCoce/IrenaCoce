function Pictures(){
    this.src= 'http://as01.epimg.net/futbol/imagenes/2018/03/26/internacional/1522045577_102459_1522045760_noticia_normal.jpg';

    this.altText = 'lorem ipsum';
   
}